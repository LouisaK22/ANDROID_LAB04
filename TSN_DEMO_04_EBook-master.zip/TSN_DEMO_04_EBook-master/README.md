# TSN_DEMO_04_EBook
Электронная книга

![Screenshot](screenshot1.png)

![Screenshot](screenshot2.png)

https://www.youtube.com/watch?v=LGl9R8_IgNU

Прокрутка WebView клавишами громкости:
https://gist.github.com/proffix4/45eee6d9bb511512efccb535e46fa465
